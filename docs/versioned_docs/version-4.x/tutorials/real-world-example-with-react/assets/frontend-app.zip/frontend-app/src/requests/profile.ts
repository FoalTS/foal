export async function updateProfile(username: string, avatar: File|null): Promise<void> {
  throw new Error('Not implemented yet!');
}