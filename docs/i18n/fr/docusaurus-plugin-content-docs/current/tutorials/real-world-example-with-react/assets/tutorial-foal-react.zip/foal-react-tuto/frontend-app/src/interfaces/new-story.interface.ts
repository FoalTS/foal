export interface INewStory {
  title: string;
  link: string;
}