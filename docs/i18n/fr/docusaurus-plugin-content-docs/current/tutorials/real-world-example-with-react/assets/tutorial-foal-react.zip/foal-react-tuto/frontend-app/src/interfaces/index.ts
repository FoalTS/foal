export type { ICredentials } from './credentials.interface';
export type { INewStory } from './new-story.interface';
export type { IStory } from './story.interface';
export type { IUser } from './user.interface';